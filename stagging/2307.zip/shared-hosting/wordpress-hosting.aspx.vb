﻿
Partial Class shared_hosting_wordpress_hosting
    Inherits System.Web.UI.Page

End Class
